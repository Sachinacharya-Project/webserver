def _data():
    print('Please USETh')