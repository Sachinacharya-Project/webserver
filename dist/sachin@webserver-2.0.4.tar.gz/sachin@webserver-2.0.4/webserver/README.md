## Downloads
Download different versions of installer from here
____
* v1.0.1 `Packages has been removed`
* v1.0.2 `Packages has been removed`
* v1.0.3 `Packages has been removed`
* v2.0.1 `Packages has been removed`  
* v2.0.2  
[sachin_webserver-2.0.2-py3-none-any.whl](https://github.com/sachin-acharya-projects/webserver/raw/main/dist/sachin_webserver-2.0.2-py3-none-any.whl)

    Installation via pip
    ````cmd
    pip install sachin-webserver
    ````

* Latest  
    ````cmd
    pip install git+https://github.com/sachin-acharya-projects/webserver
    ````
