def _data():
    print('Please use command-line tool. Details in README File')
